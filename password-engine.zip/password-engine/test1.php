<?php

$connection = ssh2_connect('vgg218yr', 22);
ssh2_auth_password($connection, 'alive007', 'Acc@0623');

/*$stream = ssh2_exec($connection, 'getRemoteHost');

stream_set_blocking($stream, true);
   $output = ssh2_fetch_stream($stream, SSH2_STREAM_STDIO);
   stream_get_contents($output);
  */
/*
include('MTS-master/MTS/EnableMTS.php');

//first you get a shell on the first server:
 $shellObj = \MTS\Factories::getDevices()->getRemoteHost('195.233.238.110')->setConnectionDetail('alive007', 'Acc@0623')->getShell();

//then build on that first shell, the following way.
\MTS\Factories::getDevices()->getRemoteHost('195.233.238.7')->setConnectionDetail('alive007', 'Acc@0623')->getShell($shellObj);


//any command executed on the shell will run only on the second host you connected to.
$return1  = $shellObj->exeCmd("whoami");
echo $return1;//hostname of the second host you connected to
*/

$host = "195.233.238.110";
$port = 22;
$username = "alive007";
$password = "Acc@0623";
$connection = NULL;

$passSvr = "Acc@0623";
$SvrBUser = "alive007";
$SvrBHost = "195.233.238.5";

try {
    $connection = ssh2_connect($host, $port);
    if(!$connection){
        throw new \Exception("Could not connect to $host on port $port");
    }
    $auth  = ssh2_auth_password($connection, $username, $password);
    if(!$auth){
        throw new \Exception("Could not authenticate with username $username and password ");
    }
    if($connection){

    $contents = ssh2_exec($connection, "sshpass -p '{$passSvr}' ssh $SvrBUser@$SvrBHost ls -al");
    stream_set_blocking($contents, true);
   $output = ssh2_fetch_stream($contents, SSH2_STREAM_STDIO);
   echo stream_get_contents($output);

        }

} catch (Exception $e) {
    echo "Error due to :".$e->getMessage();
}

?>