<!-- Sidebar -->
			<div class="sidebar" id="sidebar">
				<div class="sidebar-inner slimscroll">
					<div id="sidebar-menu" class="sidebar-menu">
						<ul>
							
							<li id="dashboard">
								<a href="dashboard.php"><i class="fa fa-desktop"></i></a>
								<p class="sidebar-txt">Dashboard</p>
							</li>
							
							<?php if($_SESSION['aRole'] == 0){?>
								
								<li id="pwadmins" class="">
									<a href="all-admins.php"><i class="fa fa-suitcase"></i></a>
									<p class="sidebar-txt">Admins</p>
								</li>
								
								<li id="pwmarkets" class="">
									<a href="all-markets.php"><i class="fa fa-user"></i></a>
									<p class="sidebar-txt">Markets</p>
							    </li>
								
							<?php } ?>

								<li id="pwusers" class="">
									<a href="all-users.php"><i class="fa fa-user-o"></i></a>
									<p class="sidebar-txt">Users</p>
								</li>
								
								<li id="Roles" class="">
									<a href="all-roles.php"><i class="fa fa-bookmark-o"></i></a>
									<p class="sidebar-txt">Roles</p> 
								</li>
								
								<li id="RoleRequests" class="">
									<a href="all-roles-requests.php"><i class="fa fa-ticket"></i></a>
									<p class="sidebar-txt">Role Requests</p> 
								</li>
								
								<!--<li id="Servers" class="">
									<a href="all-servers.php"><i class="fa fa-cloud"></i></a>
									<p class="sidebar-txt"><?= $_SESSION['aMarket'] == 1 ? 'DB' : 'Servers'; ?></p> 
								</li>-->
								
								<li id="Servers" class="">
									<a href="all-servers.php"><i class="fa fa-cloud"></i></a>
									<p class="sidebar-txt">Servers / DB</p> 
								</li>
								
								<!--<li id="ServerUser" class="">
									<a href="all-servers-owner.php"><i class="fa fa-user-plus"></i></a>
									<p class="sidebar-txt"><?= $_SESSION['aMarket'] == 1 ? 'DB Users' : 'Server Users'; ?></p> 
								</li>-->
								
								<li id="ServerUser" class="">
									<a href="all-servers-owner.php"><i class="fa fa-user-plus"></i></a>
									<p class="sidebar-txt">Users</p> 
								</li>
								
								
								<li id="passwordEncryption" class="">
									<a href="password-encryption.php"><i class="fa fa-expeditedssl"></i></a>
									<p class="sidebar-txt">Code Level Password Encryption </p> 
								</li>
								
								<li id="help" class="">
									<a href="#"><i class="fa fa-info-circle"></i></a>
									<p class="sidebar-txt">Help</p> 
								</li>
							
								<li class="list-divider"></li>
								
								<li>
								  <a href="../logout.php?key=0"><i class="fa fa-sign-out"></i></a>
								  <p class="sidebar-txt">Logout </p> 
								<li>
								
						</ul>
					</div>
				</div>
			</div>
<!-- /Sidebar -->