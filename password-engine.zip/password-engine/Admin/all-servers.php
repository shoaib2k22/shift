<?php
$table_name = "servers";
$alert = "";

include('controller/select.php');
include("includes/header.php");

$sql_show_hide = "SELECT * FROM show_hide_columns WHERE table_name = 'servers'";
	$result_show_hide = $conn->query($sql_show_hide);
	$row_show_hide = mysqli_fetch_array($result_show_hide);
	
	
	$arr = [];
	
	for($i=0; $i<=11; $i++){
		$value = $row_show_hide['column_'.$i];
		
		if(!$value){
			array_push($arr,$i);
		}
	}
	
	$column = array('serialize_#', 'owner', 'server_name', 'IP_address', 'market', 'created_on', 'users', 'status', 'actions');
	
?>

<style>
.page-wrapper > .content {
    padding-top: 4rem;
}

.dbTable {
	display:none;
}
</style>



<div class="page-wrapper">
	<div class="content container-fluid">
	  
	   <div class="row page-titles">
			<div class="col-md-5 align-self-center">
				<h6 class="text-themecolor">Servers / DB</h6>
			</div>
			<div class="col-md-7 align-self-center text-right pr-1">
				<div class="d-flex justify-content-end align-items-center mr-2">
					<ol class="breadcrumb">
						<li class="breadcrumb-item">Home</li>
						<li class="breadcrumb-item">Servers / DB</li>
					</ol>
					<button class="btn btn-danger float-right veiwbutton ml-3 serverTable" onclick="getForm('addServer')">
					    <i class="fa fa-plus-circle"></i> Add Server
					</button>
					<button class="btn btn-danger float-right veiwbutton ml-3 dbTable" onclick="getForm('addDB')">
					    <i class="fa fa-plus-circle"></i> Add DB
					</button>
					<!--<button class="btn btn-primary float-right veiwbutton ml-3" onclick="AddOrDeleteServerUserForm('ServerUser')">Add / Remove User</button>-->
					<a class="cursor-pointer float-right ml-3" data-toggle="modal" data-target="#selectColumn"><i class="fa fa-columns"></i></a>
				</div>
			</div>
		</div>
		
		<div class="page-header">
			
			<div class="row justify-content-end mb-3">
				<div class="col-2">
				  <select class="form-control" onchange="selectType(this.value)">
					  <option value="server">Server</option>
					  <option value="db">DB</option>
				  </select>
				</div>
				
				<div class="col-12">
					<?php echo $alert; ?>
				</div>
			</div>
			
			<div class="row serverTable">
			   <div class="col-sm-12">
				  <div class="card card-table">
					 <div class="card-body booking_card">
						<div class="table-responsive">
							<table class="datatable table table-stripped table table-hover table-center mb-0">
								<thead>
									<tr>
										<th>#</th>
										<!--<th>Owner</th>-->
										<th>Server Name</th>
										<th>IP Address</th>
										<th>Market</th>
										<th>Created On</th>
										<th class="text-center">Users List</th>
										<!--<th>Status</th>-->
										<th class="text-right">Actions</th>
									</tr>
								</thead>
								<tbody>
								 <?php
								  foreach( $result as $key=>$row ) { ?>
									<tr>
									    <td><?=++$key?></td>
										<!--<td><?=$row["owner"]?></td>-->
										<td class="text-lowercase"><?=$row["host_name"]?></td>
										<td><?=$row["ip_address"]?></td>
										<td><?=$row["market"]?></td>
										<td><?=date('d-M-Y', strtotime($row["created_at"]))?></td>
										<td class="text-center">
										  <button class="btn btn-status p-0" onclick="getUser('<?=$row["id"]?>', '<?=$row["host_name"]?>')">
											<i class="fa fa-eye text-info"></i> View
										  </button>
										</td>
										<!--
										<td>
										   <button type="submit" class="btn <?php echo $row["status"] == 1 ? 'btn-success' : 'btn-secondary' ?>" onclick="updateStatusOnDB('<?=$row["id"]?>','dS','<?=$row["status"]?>')">
											   <?php echo $row["status"] == 1 ? 'Active' : 'Inactive' ?>
										  </button>
										</td>
										-->
										<td class="text-right">
											<div class="dropdown dropdown-action">
											  <a href="#" class="action-icon dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
											   <i class="fa fa-th-list ellipse_color"></i>
											  </a>
											  
											  <div class="dropdown-menu dropdown-menu-right">
												  
												  <button class="dropdown-item" href="#" onclick="editForm('<?=$row["id"]?>','dS')">
													<i class="fa fa-pencil-square-o m-r-5 text-primary"></i> Edit Server
												  </button>
												  
												  <button class="dropdown-item" href="#" data-toggle="modal" data-target="#delete_asset" onclick="deleteOnDB('<?=$row["id"]?>','<?=$row["host_name"]?>','dS')">
												   <i class="fa fa-trash-o m-r-5 text-danger"></i> Delete Server
												  </button>
												  <!--
												  <button class="dropdown-item" onclick="AssigneOrDeleteForm('<?=$row["id"]?>','ServerUser')">
												   <i class="fa fa-plug m-r-5 text-warning"></i>Add / Remove User
												  </button>
												  -->
												
												</div>
											   </div>
										    </td>
										</tr>
									 <?php } ?>
								</tbody>
							</table>
						</div>
					</div>
				 </div>
			 </div>
		  </div>
		  
		  
		  
		  
		  <div class="row dbTable">
			   <div class="col-sm-12">
				  <div class="card card-table">
					 <div class="card-body booking_card">
						<div class="table-responsive">
							<table class="datatable table table-stripped table table-hover table-center mb-0">
								<thead>
									<tr>
										<th>#</th>
										<!--<th>Owner</th>-->
										<th>DB Name</th>
										<th>IP Address</th>
										<th>Market</th>
										<th>Created On</th>
										<th class="text-center">Users List</th>
										<!--<th>Status</th>-->
										<th class="text-right">Actions</th>
									</tr>
								</thead>
								<tbody>
								 <?php
								  foreach( $result_db as $key=>$row ) { ?>
									<tr>
									    <td><?=++$key?></td>
										<!--<td><?=$row["owner"]?></td>-->
										<td class="text-lowercase"><?=$row["db_name"]?></td>
										<td><?=$row["ip_address"]?></td>
										<td><?=$row["market"]?></td>
										<td><?=date('d-M-Y', strtotime($row["created_at"]))?></td>
										<td class="text-center">
										  <button class="btn btn-status p-0" onclick="getUser('<?=$row["id"]?>', '<?=$row["db_name"]?>')">
											<i class="fa fa-eye text-info"></i> View
										  </button>
										</td>
										<!--
										<td>
										   <button type="submit" class="btn <?php echo $row["status"] == 1 ? 'btn-success' : 'btn-secondary' ?>" onclick="updateStatusOnDB('<?=$row["id"]?>','dS','<?=$row["status"]?>')">
											   <?php echo $row["status"] == 1 ? 'Active' : 'Inactive' ?>
										  </button>
										</td>
										-->
										<td class="text-right">
											<div class="dropdown dropdown-action">
											  <a href="#" class="action-icon dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
											   <i class="fa fa-th-list ellipse_color"></i>
											  </a>
											  
											  <div class="dropdown-menu dropdown-menu-right">
												  
												  <button class="dropdown-item" href="#" onclick="editForm('<?=$row["id"]?>','dB')">
													<i class="fa fa-pencil-square-o m-r-5 text-primary"></i> Edit DB
												  </button>
												  
												  <button class="dropdown-item" href="#" data-toggle="modal" data-target="#delete_asset" onclick="deleteOnDB('<?=$row["id"]?>','<?=$row["db_name"]?>','dB')">
												   <i class="fa fa-trash-o m-r-5 text-danger"></i> Delete DB
												  </button>
												  <!--
												  <button class="dropdown-item" onclick="AssigneOrDeleteForm('<?=$row["id"]?>','ServerUser')">
												   <i class="fa fa-plug m-r-5 text-warning"></i>Add / Remove User
												  </button>
												  -->
												
												</div>
											   </div>
										    </td>
										</tr>
									 <?php } ?>
								</tbody>
							</table>
						</div>
					</div>
				 </div>
			 </div>
		  </div>
		  
		  
	  </div>
   </div>
</div>
	
	
	
<!-- Modal's -->
 <div id="getUserModal"></div>
 <div id="getFormModal"></div>
 <div id="getStatusModal"></div>
<!-- Model's -->


<div class="modal fade delete-modal" id="selectColumn" data-keyboard="false" data-backdrop="static">
	<div class="modal-dialog modal-dialog-centered">
		<div class="modal-content">

			<!-- Modal Header -->
			<div class="modal-header">
				<h4 class="modal-title">Column Selection</h4>
				<button type="button" class="close" data-dismiss="modal">&times;</button>
			</div>

            <!-- Modal body -->
			<div class="modal-body" style="height: 66vh;overflow-y: auto;">
			    <form id="show_hide_column">
					<div class="row formtype">
						<?php for($k=0; $k<sizeof($column); $k++){?>
							<div class="col-md-12">
								<div class="form-group toggle-group-custom">
									<span class="text-capitalize"><?php echo str_replace('_', ' ', $column[$k]); ?></span>
									<input type="checkbox" name="<?php echo $column[$k]; ?>" data-toggle="toggle" data-style="slow" value="<?php echo $row_show_hide['column_'.$k]; ?>" <?php if($row_show_hide['column_'.$k]){echo "checked";} ?>>
								</div>
							</div>
						<?php } ?>
					</div>
				</form>
			</div>
			
		    <!-- Modal footer -->
			<div class="modal-footer float-right">
				  <button type="button" class="btn btn-danger" onclick="show_hide('Servers')">Save Changes</button>
				  <button type="button" class="btn btn-dark" data-dismiss="modal">Close</button>
			</div>
						
		</div>
		 
	</div>
</div>


<!-- jQuery -->
<script>  
	var element = document.getElementById("Servers");
	   element.classList.add("active");
	  
</script>
<?php include("includes/footer.php"); ?>
	
