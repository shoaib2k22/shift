<?php
$table_name = "admins";
$alert = "";

include('controller/select.php');
include("includes/header.php");

?>


<div class="page-wrapper">
	<div class="content container-fluid">
	    
		<div class="row page-titles">
			<div class="col-md-5 align-self-center">
				<h6 class="text-themecolor">Admins</h6>
			</div>
			<div class="col-md-7 align-self-center text-right pr-1">
				<div class="d-flex justify-content-end align-items-center">
					<ol class="breadcrumb">
						<li class="breadcrumb-item">Home</li>
						<li class="breadcrumb-item">Admins</li>
					</ol>
					<button class="btn btn-danger float-right veiwbutton ml-3" onclick="getForm('addAdmin')">
					   <i class="fa fa-plus-circle"></i> Add Admin
					</button>
				</div>
			</div>
		</div>
	
		<div class="page-header">
			<div class="row">
			  <div class="col-12">
				<?php echo $alert; ?>
			  </div>
			</div>
			
			<div class="row">
			   <div class="col-sm-12">
				  <div class="card card-table">
					<div class="card-body booking_card">
						<div class="table-responsive">
							<table class="datatable table table-stripped table table-hover table-center mb-0">
								<thead>
									<tr>
										<th>Name</th>
										<th>Email</th>
										<th>Phone</th>
										<th>Market</th>
										<th>Status</th>
										<th>Created At</th>
										<th class="text-right">Actions</th>
									</tr>
								</thead>
								<tbody>
									<?php
										if(1){
											//while($row = oci_fetch($result)){
											while($row = mysqli_fetch_assoc($result)){ ?>
												
												 <tr>
													<td><?=$row["f_name"].' '.$row["l_name"]?></a></td>
													<td><?=$row["email"]?></td>
													<td><?=$row["mobile"]?></td>
													<td><?=$row["market"]?></td>
													
													
													<td>
													   <button type="submit" class="btn <?php echo $row["status"] == 1 ? 'btn-success' : 'btn-secondary' ?>" onclick="updateStatusOnDB('<?=$row["id"]?>','dA','<?=$row["status"]?>')">
														   <?php echo $row["status"] == 1 ? 'Active' : 'Inactive' ?>
														</button>
													</td>
													
													
													<td><?=date('d-M-Y',strtotime($row["created_at"]))?></a></td>
													
													<td class="text-right">
														<div class="dropdown dropdown-action">
														  <a href="#" class="action-icon dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
														   <i class="fa fa-ellipsis-v ellipse_color"></i>
														  </a>
														  
														  <div class="dropdown-menu dropdown-menu-right">
															  
															  <a class="dropdown-item" href="#" onclick="editForm('<?=$row["id"]?>','dA')">
																<i class="fa fa-pencil m-r-5"></i> Edit
															  </a>
															  
															  <a class="dropdown-item" href="#" data-toggle="modal" data-target="#delete_asset" onclick="deleteAlert('<?=$row["id"]?>','<?=$row["f_name"]?>','dA')">
															   <i class="fa fa-trash-o m-r-5"></i> Delete
															  </a>
														  </div>
														  
														</div>
													</td>
												</tr>
									   <?php
										  }
										}
										else{
										 echo "No record found";
										}
									  ?>
								</tbody>
							</table>
						</div>
					 </div>
				  </div>
			   </div>
		   </div>
	    </div>
    </div>
</div>


<!-- Modal's -->
 <div id="getFormModal"></div>
 <div id="getStatusModal"></div>
<!-- Model's -->

	

	
<!-- jQuery -->
<script>
	var element = document.getElementById("pwadmins");
	   element.classList.add("active");
</script>

<?php include("includes/footer.php"); ?>




