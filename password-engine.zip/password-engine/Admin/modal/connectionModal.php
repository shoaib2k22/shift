<?php
$modalName = "connectionModal";

include('../controller/modal.php');
?>

<div class="modal fade delete-modal" id="getconnectionPerRole">
  <div class="modal-dialog modal-dialog-centered modal-lg">
    <div class="modal-content">

	  <!-- Modal Header -->
	  <div class="modal-header">
		<h4 class="modal-title text-captilize"><?php echo $role; ?></h4>
		<button type="button" class="close" data-dismiss="modal">&times;</button>
	  </div>

	  <!-- Modal body -->
	  <div class="modal-body">
		 <div class="table-responsive">
			<table class="datatable table table-stripped table table-hover table-center mb-0">
			   <?php if($total >0){?> 
				<thead>
					<tr>
						<th>#</th>
						<th>Host</th>
						<th>IP Address</th>
						<th>User</th>
						<th>Market</th>
						<th>Created_at</th>
						<th>Status</th>
					</tr>
				</thead>
				<tbody>
				  <?php
					foreach( $result as $key=>$row ){ ?>
						<tr>
							<td><?=++$key;?></td>
							<td><?=$row["host_name"]?></td>
							<td><?=$row["ip_address"]?></td>
							<td><?=$row["user"]?></td>
							<td><?=$row["market"]?></td>
							<td><?= date('d-M-Y', strtotime($row["created_at"]))?></td>
							<td>
							   <button type="submit" class="btn btn-success btn-status" onclick="updateStatusOnDB('<?=$row["id"]?>','dS','<?=$row["status"]?>')">
								   <?php echo $row["status"] == 1 ? 'Active' : 'Inactive' ?>
							  </button>
							</td>
						</tr>
				   <?php }?>
				</tbody>
			   <?php } 
			     else{
					 echo "No record found";
				 }?>
			</table>
		  </div>
	  </div>
	  <!-- Modal body end-->
	  
	  <!-- Modal footer -->
	  <div class="modal-footer float-right">
			<button type="button" class="btn btn-dark" data-dismiss="modal">Close</button>
	  </div>
	  <!-- Modal footer end-->
	  
    </div>
  </div>
</div>
