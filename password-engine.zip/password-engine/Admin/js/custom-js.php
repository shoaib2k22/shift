<script>

function seheduleJob(){
	
	$('#loaderImg').show();
	$.ajax({
		 url:'../seheduleJob.php',
		 type:'POST',
		 success:function(result){
			$('#loaderImg').hide();
			var response = JSON.parse(result);
			
			if (response.code == 200) {
				Swal.fire({
					text: response.text,
					icon: response.msg,
					showCancelButton: true,
					showConfirmButton: false,
					cancelButtonColor: '#d33',
					cancelButtonText: 'Close'
				});
			}
		 }
	 });	
}

function validateEmail(value){
	
  if(value.split("@").length-1!==1 || value.split('@')[0].length===0 || value.split('@')[1]!=='vodafone.com'){
	  $('#ErrorEmail').text(value + ' is invalid email.');
	  $('#ErrorUser').text(value + ' is invalid email.');
	  $("#insertUserBtn").prop("disabled", true);
	  $("#saveServerUser").prop("disabled", true);
  } else{
	  $('#ErrorEmail').text('');
	  $('#ErrorUser').text('');
	  $("#insertUserBtn").removeAttr('disabled');
	  $("#saveServerUser").removeAttr('disabled');
  }
}


function selectType(item){
	if(item == 'server'){
		$('.serverTable').show();
		$('.dbTable').hide();
	} else{
		$('.serverTable').hide();
		$('.dbTable').show();
	}
}

function validateServer(){
     let server = $('#host').val();
     
	 $('#loaderImg').show();
	 $.ajax({
		 url:'../validateServer.php',
		 type:'POST',
		 data:{
			   server:server,
			 },
		 success:function(result){
			$('#loaderImg').hide();
			var response = JSON.parse(result);
			$('#ErrorHost').html('');
			 
			if (response.code == 200) {
				$('#host').css("border-color", "#008000");
				$('#ErrorHost').html(response.msg);
				$('#ErrorHost').attr('style', "color: #008000 !important");
				$('#addServer').show();
				
			} else {
				$('#host').css("border-color", "#e84646");
				$('#ErrorHost').html(response.msg);
				$('#ErrorHost').attr('style', "color: #e84646 !important");
				$('#addServer').hide();
			}
		 }
	 });	 
}


function validateDb(){
     let db = $('#db').val();
     
	 $('#loaderImg').show();
	 $.ajax({
		 url:'../validateDB.php',
		 type:'POST',
		 data:{
			   db:db,
			 },
		 success:function(result){
			$('#loaderImg').hide();
			var response = JSON.parse(result);
			$('#ErrorDB').html('');
			 
			if (response.code == 200) {
				$('#db').css("border-color", "#008000");
				$('#ErrorDB').html(response.msg);
				$('#ErrorDB').attr('style', "color: #008000 !important");
				$('#addDb').show();
				
			} else {
				$('#db').css("border-color", "#e84646");
				$('#ErrorDB').html(response.msg);
				$('#ErrorDB').attr('style', "color: #e84646 !important");
				$('#addDb').hide();
			}
		 }
	 });	 
}


function validate(){
	 $('.form-control-error').empty();
	 
	 let ticket = $('input[name = ticket]').val();
	 let serverName = $('#server').find(":selected").val();
	 let userName = $('input[name = userName]').val();
	 let userValue = $('input[name = userPassword]').val();
	 let userOwner = $('input[name = user]').val();
	 
	 if(ticket == '' || serverName == '' || userName == '' || userValue == '' || userOwner == ''){
		 let ErrorTicket = ticket =='' ? "Ticket No. is required" : "";
		 let ErrorServer = serverName =='' ? "Server is required" : "";
		 let ErrorUserName = userName =='' ? "User name is required" : "";
		 let ErrorPassword = userValue =='' ? "User password is required" : "";
		 let ErrorUser = userOwner =='' ? "User Owner email is required" : "";
		    $('#ErrorTicket').html(ErrorTicket);
		    $('#ErrorServer').html(ErrorServer);
		    $('#ErrorUserName').html(ErrorUserName);
			$('#ErrorPassword').html(ErrorPassword);
			$('#ErrorUser').html(ErrorUser);
		 return;
	 }
     
	 $('#loaderImg').show();
	 $.ajax({
		 url:'../validate.php',
		 type:'POST',
		 data:{
			   serverName:serverName,
			   userName:userName,
			   userValue:userValue,
			 },
		 success:function(result){
			$('#loaderImg').hide();
			var response = JSON.parse(result);
			
			if (response.code == 200) {
				$('#saveServerUser').removeAttr("disabled");
				$('#validationMessage').html(response.msg);
				$('#validationMessage').attr({style:"color: #008000 !important; display: block"});
			} else {
				$('#saveServerUser').attr('disabled', true);
				$('#validationMessage').html(response.msg);
				$('#validationMessage').attr({style: "color: #e84646 !important; display: block"});
			}
			
		 }
	 });	 
}


function getSourceUser(server) {
	 //alert(server);
	 $('#loaderImg').show();
	 $.ajax({
		 url:'modal/getSourceUserModal.php',
		 type:'POST',
		 data:{
			   server:server,
			 },
		 success:function(result){
			 $('#loaderImg').hide();
			 $('#sourceUser').html(result);
		 }
	 });
}


function getTargetUser(server) {
	 //alert(server);
	 $('#loaderImg').show();
	 $.ajax({
		 url:'modal/getTargetUserModal.php',
		 type:'POST',
		 data:{
			   server:server,
			 },
		 success:function(result){
			 $('#loaderImg').hide();
			 $('#targetUser').html(result);
		 }
	 });
}


function getServerUser(server) {
	 //alert(server);
	 $('#loaderImg').show();
	 $.ajax({
		 url:'modal/getServerUserModal.php',
		 type:'POST',
		 data:{
			   server:server,
			 },
		 success:function(result){
			 $('#loaderImg').hide();
			 $('#GetServerUser').html(result);
		 }
	 });
}
   
function getForm(key) {
	 //alert(key);
	 $.ajax({
		 url:'modal/addModal.php',
		 type:'POST',
		 data:{
			   key:key,
			 },
		 success:function(result){
			 $('#loaderImg').hide();
			 $('#getFormModal').html(result);
			 $('#successMsgModal').modal('hide');
			 $('#addFormModal').modal('show');
		 }
	 });
   }
   
function getRoleAssignForm(uID){
	//alert(key);
	 $('#loaderImg').show();
	 $.ajax({
		 url:'modal/addGrantModal.php',
		 type:'POST',
		 data:{
			   uID:uID,
			 },
		 success:function(result){
			  $('#loaderImg').hide();
			 $('#getFormModal').html(result);
			 $('#successMsgModal').modal('hide');
			 $('#addFormModal').modal('show');
		 }
	 });
}
	
	
function AssigneOrDeleteForm(id,key) {
	 //alert(key);
	  $('#loaderImg').show();
	 $.ajax({
		 url:'modal/AssigneOrDeleteModal.php',
		 type:'POST',
		 data:{
			   id:id,
			   key:key,
			 },
		 success:function(result){
			  $('#loaderImg').hide();
			 $('#getFormModal').html(result);
			 $('#successMsgModal').modal('hide');
			 $('#addFormModal').modal('show');
		 }
	 });
   }
	
	
	function getServerAssignForm(rID){
	    //alert(key);
		 $('#loaderImg').show();
		 $.ajax({
			 url:'modal/addServerModal.php',
			 type:'POST',
			 data:{
				   rID:rID,
				 },
			 success:function(result){
				 $('#loaderImg').hide();
				 $('#getFormModal').html(result);
				 $('#successMsgModal').modal('hide');
				 $('#addFormModal').modal('show');
			 }
		 });
	}
	
	function getUserAssignForm(sID){
	    //alert(key);
		 $('#loaderImg').show();
		 $.ajax({
			 url:'modal/AssigneOrDeleteServersUserModal.php',
			 type:'POST',
			 data:{
				   sID:sID,
				 },
			 success:function(result){
				 $('#loaderImg').hide();
				 $('#getFormModal').html(result);
				 $('#successMsgModal').modal('hide');
				 $('#addFormModal').modal('show');
			 }
		 });
	}
 
 
 function AddOrDeleteServerUserForm(key){
	    //alert(key);
		 $('#loaderImg').show();
		 $.ajax({
			 url:'modal/AssigneOrDeleteServersUserModal.php',
			 type:'POST',
			 data:{
				   key:key,
				 },
			 success:function(result){
				 $('#loaderImg').hide();
				 $('#getFormModal').html(result);
				 $('#successMsgModal').modal('hide');
				 $('#addFormModal').modal('show');
			 }
		 });
	}

/* $(document).ready(function(){
	$('#ticket').on('keyup',function(e){
		if(e.keyCode == 13){
			$('#ErrorTicket').empty();
		}
	});
}); */

$('input[type="checkbox"]').change(function(){
	if(this.checked){
		this.value = 1;
	}
	else{
		this.value = 0;
	}
});

function show_hide(key){
	var formData = $('#show_hide_column').serialize() + '&key=' + key;
	/*
	$.each($('form input[type=checkbox]')
		.filter(function(idx){
			return $(this).prop('checked') === false
		}),
		function(idx, el){
			let val = 0;
			formData += '&' + $(el).attr('name') + '=' + val;
		}
	);
	*/
	
	Swal.fire({
            title: '',
            text: 'Are you sure?',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes, Change it!'
            }).then((result) => {
			
			  if(result.isConfirmed){
				 $('#loaderImg').show();
				 $.ajax({
				 url:'controller/updateHideShow.php',
				 type:'GET',
				 data: formData,
				 success:function(result){
					 //console.log(typeof result);
					 $('#loaderImg').hide();
					 var response = JSON.parse(result);
					 
					 Swal.fire({
								text: response.text,
								icon: response.msg,
								showCancelButton: true,
								showConfirmButton: false,
								cancelButtonColor: '#d33',
								cancelButtonText: 'Close'
							}).then((result) => {
							    location.reload();
					    });
				    }
				});
			  }
			});
}

function AssigneOrDelete(value) {
	 $('.form-control-error').empty();
	 let data = $('#addFormData').serialize() + value;
	 //alert(data)
	 let action = $('#action').find(":selected").val();
	 let role = $('#role').find(":selected").val();
	 let server = $('#server').find(":selected").val();
	 let user = $('#user').find(":selected").val();
	 let ticket = $('input[name = ticket]').val();
	 let userName = $('input[name = userName]').val();
	 
	 if(ticket == '' || role == '' || server == '' || user == '' || userName == ''){
		 let ErrorTicket = ticket =='' ? "Ticket No. is required" : "";
		 let ErrorRole = role =='' ? "Role is required" : "";
		 let ErrorServer = server =='' ? "Server is required" : "";
		 let ErrorUser = user =='' ? "User is required" : "";
		 let ErrorUserName = userName =='' ? "User name is required" : "";
		    $('#ErrorTicket').html(ErrorTicket);
		    $('#ErrorRole').html(ErrorRole);
		    $('#ErrorServer').html(ErrorServer);
		    $('#ErrorUser').html(ErrorUser);
		    $('#ErrorUserName').html(ErrorUserName);
		 return;
	 }
	 
	 if(action == 'add'){
		 Swal.fire({
            title: '',
            text: 'Are you sure?',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes, Add it!'
            }).then((result) => {
			
			  if(result.isConfirmed){
				 $('#loaderImg').show();
				 $.ajax({
				 url:'controller/insertAssigned.php',
				 type:'POST',
				 data: data,
				 success:function(result){
					 //console.log(typeof result);
					 $('#loaderImg').hide();
					 var response = JSON.parse(result);
					 $('#getStatusModal').html(result);
					 $('.form-control-error').html('');
					 
					 if(response.code != 200){
						 //console.log(response.code);
						 $('#ErrorFName').html(response.f_name);
						 $('#ErrorLName').html(response.l_name);
						 $('#ErrorEmail').html(response.email);
						 $('#ErrorMobile').html(response.mobile);
						 $('#ErrorMarket').html(response.market);
						 $('#ErrorStatus').html(response.status);
						 $('#ErrorRole').html(response.role);
						 $('#ErrorOwner').html(response.owner);
						 $('#ErrorServer').html(response.host);
						 $('#ErrorIp').html(response.ip);
						 $('#ErrorPort').html(response.port);
						 $('#ErrorOs').html(response.os_type);
						 $('#ErrorPassword').html(response.password);
						 $('#ErrorEmployee').html(response.employee_id);
						 $('#ErrorUser').html(response.user);
						 $('#ErrorUserName').html(response.userName);
						 $('#ErrorAction').html(response.action);
					 }
					 else{
						 //$('#getStatusModal').html(response.msg);
						 $('#addFormModal').modal('hide');
						 //$('#successMsgModal').modal('show');
						 Swal.fire({
								text: response.text,
								icon: response.msg,
								showCancelButton: true,
								showConfirmButton: false,
								cancelButtonColor: '#d33',
								cancelButtonText: 'Close'
							}).then((result) => {
							    location.reload();
					    });
					 }
				   }
			    });
		      }
	       });
	 }
	 else{
		 Swal.fire({
            title: '',
            text: 'Are you sure?',
            icon: 'error',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes, Remove it!'
            }).then((result) => {
			
			  if(result.isConfirmed){
		         $('#loaderImg').show();
				 $.ajax({
				 url:'controller/deleteAssigned.php',
				 type:'POST',
				 data: data,
				 success:function(result){
					 $('#loaderImg').hide();
					 //console.log(typeof result);
					 var response = JSON.parse(result);
					 //var response = result;
					 $('.form-control-error').html('');
					 
					 if(response.code != 200){
						 //console.log(response.code);
						 $('#ErrorFName').html(response.f_name);
						 $('#ErrorLName').html(response.l_name);
						 $('#ErrorEmail').html(response.email);
						 $('#ErrorMobile').html(response.mobile);
						 $('#ErrorMarket').html(response.market);
						 $('#ErrorStatus').html(response.status);
						 $('#ErrorRole').html(response.role);
						 $('#ErrorOwner').html(response.owner);
						 $('#ErrorServer').html(response.host);
						 $('#ErrorIp').html(response.ip);
						 $('#ErrorPort').html(response.port);
						 $('#ErrorOs').html(response.os_type);
						 $('#ErrorPassword').html(response.password);
						 $('#ErrorEmployee').html(response.employee_id);
						 $('#ErrorUser').html(response.user);
						 $('#ErrorAction').html(response.action);
					 }
					 else{
						 $('#getStatusModal').html(response.msg);
						 $('#addFormModal').modal('hide');
						 //$('#successMsgModal').modal('show');
						 Swal.fire({
								text: response.text,
								icon: response.msg,
								showCancelButton: true,
								showConfirmButton: false,
								cancelButtonColor: '#d33',
								cancelButtonText: 'Close'
							}).then((result) => {
							        location.reload();
					    });
					 }
				   }
			   });
		     }
		  });
	 }
	 
}





function addSSHKey(value) {
	 $('.form-control-error').empty();
	 let data = $('#addFormData').serialize() + value;
	 //alert(data)
	 let ticket = $('input[name = ticket]').val();
	 let sourceServer = $('#sourceServer').find(":selected").val();
	 let targetServer = $('#targetServer').find(":selected").val();
	 let sourceAccountType = $('#sourceAccountType').find(":selected").val();
	 let sourceUser = $('input[name = sourceUser]').val();
	 let targetUser = $('input[name = targetUser]').val();
	 let sourceSSHKey = $('#sourceSSHKey').val();
	 
	 
	 if(ticket == '' || sourceServer == '' || targetServer == '' || sourceAccountType == '' || sourceUser == '' || targetUser == '' || sourceSSHKey == ''){
		 
		 let ErrorTicket = ticket =='' ? "Ticket No. is required" : "";
		 let ErrorSourceServer = sourceServer =='' ? "Source server is required" : "";
		 let ErrorTargetServer = targetServer =='' ? "Target server is required" : "";
		 let ErrorSourceUser = sourceUser =='' ? "Source user is required" : "";
		 let ErrorTargetUser = targetUser =='' ? "Target user is required" : "";
		 let ErrorSSH = sourceSSHKey =='' ? "Source SSH key is required" : "";
		 let ErrorAccountType = sourceAccountType =='' ? "Source account type is required" : "";

		    $('#ErrorTicket').html(ErrorTicket);
		    $('#ErrorSourceServer').html(ErrorSourceServer);
		    $('#ErrorTargetServer').html(ErrorTargetServer);
		    $('#ErrorSourceUser').html(ErrorSourceUser);
		    $('#ErrorTargetUser').html(ErrorTargetUser);
		    $('#ErrorSSH').html(ErrorSSH);
		    $('#ErrorAccountType').html(ErrorAccountType);
		 return;
	 }
	 
	 if(sourceServer == targetServer){
		 let ErrorTargetServer = "Target server and Source server could not be same";
		  
		  $('#ErrorTargetServer').html(ErrorTargetServer);
		 return;
	 }
	 
	 Swal.fire({
		title: '',
		text: 'Are you sure?',
		icon: 'warning',
		showCancelButton: true,
		confirmButtonColor: '#3085d6',
		cancelButtonColor: '#d33',
		confirmButtonText: 'Yes, Add it!'
		}).then((result) => {
		
		  if(result.isConfirmed){
			 $('#loaderImg').show();
			 $.ajax({
			 url:'controller/insertAssigned.php',
			 type:'POST',
			 data: data,
			 success:function(result){
				 //console.log(typeof result);
				 $('#loaderImg').hide();
				 var response = JSON.parse(result);
				 $('.form-control-error').html('');
				 
				 if(response.code != 200){
					 //console.log(response.code);
					$('#ErrorTicket').html(response.ticket);
					$('#ErrorSourceServer').html(response.sourceServer);
					$('#ErrorTargetServer').html(response.targetServer);
					$('#ErrorSourceUser').html(response.sourceUser);
					$('#ErrorTargetUser').html(response.targetUser);
					$('#ErrorSSH').html(response.sourceSSHKey);
					$('#ErrorAccountType').html(response.sourceAccountType);
				 }
				 else{
					 //$('#getStatusModal').html(response.msg);
					 $('#addFormModal').modal('hide');
					 //$('#successMsgModal').modal('show');
					 Swal.fire({
						    text: response.text,
							input: 'textarea',
							inputValue: response.ecnrypted_key,
							icon: response.msg,
							showCancelButton: true,
							showConfirmButton: true,
							cancelButtonColor: '#d33',
							cancelButtonText: 'Close',
							confirmButtonText: 'Copy',
							//html:'<button class="btn btn-warning" onclick="clickBtn()">Copy</button>',
						}).then((result) => {
							if(result.isConfirmed){
								navigator.clipboard.writeText(result.value);
								//Swal.fire('Copied!','', 'success');
								Swal.fire({
									text: 'Copied!',
									icon: 'success',
									showCancelButton: false,
									showConfirmButton: true,
									confirmButtonText: 'Ok',
								}).then((result) => {
									if(result.isConfirmed){
										location.reload();
									} 
							    });
							} else{
								location.reload();
							}
							
					});
				 }
			   }
			});
		  }
	   });
}


function clickBtn(){
	let copyText = document.getElementsByClassName('swal2-textarea');
	console.log(copyText[0]);
	console.log(copyText[0].value);
	copyText[0].select();
	copyText[0].setSelectionRange(0, 99999); // For mobile devices
	navigator.clipboard.writeText(copyText[0].value);
}

function reset(){
	$('.form-control-error').empty();
	$('input').val('');  
	$('option:selected').remove();
	$('#addServerNotify').empty();
	$('#addRoleNotify').empty();
	
}


function assigned(key){
	//alert(key);
	if(key == 'server'){
		let form = $('#assigneServerOnUserCreation').serializeArray();
		$("#assignedServer").val(form[0].value);
		$("#assignedUser").val(form[1].value);
		//$("#addServerBtn").removeAttr('disabled');
		$("#addServerNotify").html(" You have selected "+$('#'+form[1].name+' option:selected').text()+" user on "+$('#'+form[0].name+' option:selected').text()+" server ");
		$('#assignServer').modal('hide');
	}
	else if(key == 'role'){
		let form = $('#assigneRoleOnUserCreation').serializeArray();
		$("#assignedRole").val(form[0].value);
		//$("#addServerBtn").removeAttr('disabled');
		$("#addRoleNotify").html(" You have selected "+$('#'+form[0].name+' option:selected').text()+" role");
		$('#assignRole').modal('hide');
	}
}




function addOnDB(key) {
	 //alert(key);
	
	 $('.form-control-error').empty();
	 let action = $('#action').find(":selected").val();
	 let role = $('#role').find(":selected").val();
	 let server = $('#server').find(":selected").val();
	 let user = $('#user').find(":selected").val();
	 let gender = $('#gender').find(":selected").val();
	 let os_type = $('#os_type').find(":selected").val();
	 let ticket = $('input[name = ticket]').val();
	 let userName = $('input[name = userName]').val();
	 let unix_id = $('input[name = unix_id]').val();
	 let f_name = $('input[name = f_name]').val();
	 let l_name = $('input[name = l_name]').val();
	 let email = $('input[name = email]').val();
	 let mobile = $('input[name = mobile]').val();
	 let ip = $('input[name = ip]').val();
	 let host = $('input[name = host]').val();
	 let db = $('input[name = db]').val();
	 let password = $('input[name = password]').val();
	 let confirm_password = $('input[name = confirm_password]').val();
	 

	 if(action == '' || role == '' || server == '' || user == '' || gender == '' || os_type == '' || ticket == '' || userName == '' || unix_id == '' || f_name == '' || l_name == '' || email == '' || mobile == '' || host == '' || db == '' || ip == '' || password == '' || confirm_password == ''){
		 
		 $('#ErrorAction').html(action =='' ? "Action is required" : "");
		 $('#ErrorRole').html(role =='' ? "Role is required" : "");
		 $('#ErrorServer').html(server =='' ? "Server is required" : "");
		 $('#ErrorUser').html(user =='' ? "User is required" : "");
		 $('#ErrorGender').html(gender =='' ? "Gender is required" : "");
		 $('#ErrorOs').html(os_type =='' ? "OS type is required" : "");
		 $('#ErrorTicket').html(ticket =='' ? "Ticket no. is required" : "");
		 $('#ErrorUserName').html(userName =='' ? "User name is required" : "");
		 $('#ErrorUnix').html(unix_id =='' ? "Unix Id is required" : "");
		 $('#ErrorFName').html(f_name =='' ? "First name is required" : "");
		 $('#ErrorLName').html(l_name =='' ? "Last name is required" : "");
		 $('#ErrorEmail').html(email =='' ? "Email is required" : "");
		 $('#ErrorMobile').html(mobile =='' ? "Mobile is required" : "");
		 $('#ErrorHost').html(host =='' ? "Server name is required" : "");
		 $('#ErrorDB').html(db =='' ? "DB name is required" : "");
		 $('#ErrorIp').html(ip =='' ? "IP address is required" : "");
		 $('#ErrorPassword').html(password =='' ? "Password is required" : "");
		 $('#ErrorConfirmPassword').html(confirm_password =='' ? "Confirm password is required" : "");
		
		return;
	 }
	 
	 
	 Swal.fire({
		title: '',
		text: 'Are you sure?',
		icon: 'warning',
		showCancelButton: true,
		confirmButtonColor: '#3085d6',
		cancelButtonColor: '#d33',
		confirmButtonText: 'Yes, Add it!'
		}).then((result) => {
		  if(result.isConfirmed){
			 $('#loaderImg').show();
			 $.ajax({
			 url:'controller/insert.php',
			 type:'POST',
			 data:$('#addFormData').serialize(),
			 success:function(result){
				 $('#loaderImg').hide();
				 //console.log(typeof result);
				 var response = JSON.parse(result);
				 $('.form-control-error').html('');
				 
				 if(response.code != 200){
					 //console.log(response.code);
					 $('#ErrorFName').html(response.f_name);
					 $('#ErrorLName').html(response.l_name);
					 $('#ErrorEmail').html(response.email);
					 $('#ErrorMobile').html(response.mobile);
					 $('#ErrorMarket').html(response.market);
					 $('#ErrorStatus').html(response.status);
					 $('#ErrorRole').html(response.role);
					 $('#ErrorOwner').html(response.owner);
					 $('#ErrorServer').html(response.host);
					 $('#ErrorDB').html(response.db);
					 $('#ErrorIp').html(response.ip);
					 $('#ErrorPort').html(response.port);
					 $('#ErrorOs').html(response.os_type);
					 $('#ErrorPassword').html(response.password);
					 $('#ErrorEmployee').html(response.employee_id);
					 $('#ErrorUser').html(response.user);
					 $('#ErrorAction').html(response.user);
				 }
				 else{
					 $('#getStatusModal').html(response.msg);
					 $('#addFormModal').modal('hide');
					 //$('#successMsgModal').modal('show');
					 Swal.fire({
							text: response.text,
							icon: response.msg,
							showCancelButton: true,
							showConfirmButton: false,
							cancelButtonColor: '#d33',
							cancelButtonText: 'Close'
						}).then((result) => {
							location.reload();
					});
				 }
			  }
		   });
        }
	});
}
   
   
   
   function editForm(id,key) {
	 //alert(key);
	 $('#loaderImg').show();
	 $.ajax({
		 url:'modal/editModal.php',
		 type:'POST',
		 data:{
			   id:id,
			   key:key,
			 },
		 success:function(result){
			 $('#loaderImg').hide();
			 $('#getFormModal').html(result);
			 $('#successMsgModal').modal('hide');
			 $('#editFormModal').modal('show');
		 }
	 });
   }
   
   
   
   
   
function updateOnDB(key) {
	 //alert(key);
	 $('.form-control-error').empty();
	 let action = $('#action').find(":selected").val();
	 let role = $('#role').find(":selected").val();
	 let server = $('#server').find(":selected").val();
	 let user = $('#user').find(":selected").val();
	 let gender = $('#gender').find(":selected").val();
	 let os_type = $('#os_type').find(":selected").val();
	 let ticket = $('input[name = ticket]').val();
	 let userName = $('input[name = userName]').val();
	 let unix_id = $('input[name = unix_id]').val();
	 let f_name = $('input[name = f_name]').val();
	 let l_name = $('input[name = l_name]').val();
	 let email = $('input[name = email]').val();
	 let mobile = $('input[name = mobile]').val();
	 let host = $('input[name = host]').val();
	 let db = $('input[name = db]').val();
	 let ip = $('input[name = ip]').val();
	 let password = $('input[name = password]').val();
	 let confirm_password = $('input[name = confirm_password]').val();
	 
	 if(action == '' || role == '' || server == '' || user == '' || gender == '' || os_type == '' || ticket == '' || userName == '' || unix_id == '' || f_name == '' || l_name == '' || email == '' || mobile == '' || host == '' || db == '' || ip == '' || password == '' || confirm_password == ''){
		 
		 $('#ErrorAction').html(action =='' ? "Action is required" : "");
		 $('#ErrorRole').html(role =='' ? "Role is required" : "");
		 $('#ErrorServer').html(server =='' ? "Server is required" : "");
		 $('#ErrorUser').html(user =='' ? "User is required" : "");
		 $('#ErrorGender').html(gender =='' ? "Gender is required" : "");
		 $('#ErrorOs').html(os_type =='' ? "OS type is required" : "");
		 $('#ErrorTicket').html(ticket =='' ? "Ticket no. is required" : "");
		 $('#ErrorUserName').html(userName =='' ? "User name is required" : "");
		 $('#ErrorUnix').html(unix_id =='' ? "Unix Id is required" : "");
		 $('#ErrorFName').html(f_name =='' ? "First name is required" : "");
		 $('#ErrorLName').html(l_name =='' ? "Last name is required" : "");
		 $('#ErrorEmail').html(email =='' ? "Email is required" : "");
		 $('#ErrorMobile').html(mobile =='' ? "Mobile is required" : "");
		 $('#ErrorHost').html(host =='' ? "Server name is required" : "");
		 $('#ErrorDB').html(host =='' ? "DB name is required" : "");
		 $('#ErrorIp').html(ip =='' ? "IP address is required" : "");
		 $('#ErrorPassword').html(password =='' ? "Password is required" : "");
		 $('#ErrorConfirmPassword').html(confirm_password =='' ? "Confirm password is required" : "");
		    
		return;
	 }
	 Swal.fire({
		title: '',
		text: 'Are you sure?',
		icon: 'warning',
		showCancelButton: true,
		confirmButtonColor: '#3085d6',
		cancelButtonColor: '#d33',
		confirmButtonText: 'Yes, Add it!'
		}).then((result) => {
		  if(result.isConfirmed){
			 $('#loaderImg').show();
			 $.ajax({
				 url:'controller/update.php',
				 type:'POST',
				 data:$('#editFormData').serialize(),
				 success:function(result){
					 $('#loaderImg').hide();
					 //console.log(typeof result);
					 var response = JSON.parse(result);
					 $('.form-control-error').html('');
					 
					 if(response.code != 200){
						 //console.log(response.code);
						 $('#ErrorFName').html(response.f_name);
						 $('#ErrorLName').html(response.l_name);
						 $('#ErrorEmail').html(response.email);
						 $('#ErrorMobile').html(response.mobile);
						 $('#ErrorMarket').html(response.market);
						 $('#ErrorStatus').html(response.status);
						 
						 $('#ErrorRole').html(response.role);
						 $('#ErrorOwner').html(response.owner);
						 $('#ErrorServer').html(response.host);
						 $('#ErrorDB').html(response.db);
						 $('#ErrorIp').html(response.ip);
						 $('#ErrorPort').html(response.port);
						 $('#ErrorOs').html(response.os_type);
						 $('#ErrorPassword').html(response.password);
						 $('#ErrorEmployee').html(response.employee_id);
						 $('#ErrorAction').html(response.employee_id);
					 }
					 else{
						 $('#getStatusModal').html(response.msg);
						 $('#editFormModal').modal('hide');
						 //$('#successMsgModal').modal('show');
						 Swal.fire({
							text: response.text,
							icon: response.msg,
							showCancelButton: true,
							showConfirmButton: false,
							cancelButtonColor: '#d33',
							cancelButtonText: 'Close'
						}).then((result) => {
							location.reload();
					  });
					}
				  }
			  });
		   }
	  });
}
   
   
   function updateStatusOnDB(id,key,status) {
	 //alert(id+key+status);
	 $('#loaderImg').show();
	 $.ajax({
		 url:'controller/status.php',
		 type:'POST',
		 data:{
			 id:id,
			 key:key,
			 status:status,
		 },
		 success:function(result){
			 $('#loaderImg').hide();
			 location.reload();
		}
	 });
   }
   
   function deleteAlert(id,name,key) {
		 //document.getElementById("primary_key_delete").setAttribute('value',id);
		 //alert(id + name + key);
		 $('#loaderImg').show();
		 $.ajax({
		 url:'modal/deleteModal.php',
		 type:'POST',
		 data:{
			   id:id,
			   name:name,
			   key:key,
			 },
		 success:function(result){
			 $('#loaderImg').hide();
			 $('#getFormModal').html(result);
			 $('#successMsgModal').modal('hide');
			 $('#addFormModal').modal('show');
		 }
	   });
     }
	 
    
function deleteOnDB(id,name,key){
   //alert(id + key);
   Swal.fire({
	title: '',
	text: 'Are you sure to delete '+ name+' ?',
	icon: 'error',
	showCancelButton: true,
	confirmButtonColor: '#3085d6',
	cancelButtonColor: '#d33',
	confirmButtonText: 'Yes, Delete it!'
	}).then((result) => {
	  if(result.isConfirmed){
	     $('#loaderImg').show();
		 $.ajax({
		 url:'controller/delete.php',
		 type:'POST',
		 data:{
			   id:id,
			   key:key,
			 },
		 success:function(result){
			 $('#loaderImg').hide();
			 var response = JSON.parse(result);
			 //$('#getStatusModal').html(response.msg);
			 $('#addFormModal').modal('hide');
			 //$('#successMsgModal').modal('show');
			 Swal.fire({
					text: response.text,
					icon: response.msg,
					showCancelButton: true,
					showConfirmButton: false,
					cancelButtonColor: '#d33',
					cancelButtonText: 'Close'
				}).then((result) => {
					location.reload();
			});
		 }
	   });
     }
  });
}
	 
	
	
	function getServer(key, owner) {
	 //alert(key);
	 $('#loaderImg').show();
	 $.ajax({
		 url:'modal/serverModal.php',
		 type:'POST',
		 data:{
			   key:key,
			   owner:owner,
			 },
		 success:function(result){
			 $('#loaderImg').hide();
			 $('#getServerModal').html(result);
			 $('#getserverPerOwner').modal('show');
		 }
	 });
   }
   
    function getRoleAssigned(key, user){
	   //alert(key);
	     $('#loaderImg').show();
		 $.ajax({
			 url:'modal/grantModal.php',
			 type:'POST',
			 data:{
				   key:key,
				   user:user,
				 },
			 success:function(result){
				 $('#loaderImg').hide();
				 $('#getGrantModal').html(result);
				 $('#getGrantPerUser').modal('show');
			 }
		 });
    }
   
   
   function getConnection(key, role) {
	 //alert(key);
	 $('#loaderImg').show();
	 $.ajax({
		 url:'modal/connectionModal.php',
		 type:'POST',
		 data:{
			   key:key,
			   role:role,
			 },
		 success:function(result){
			 $('#loaderImg').hide();
			 $('#getConnectionModal').html(result);
			 $('#getconnectionPerRole').modal('show');
		 }
	 });
   }
   
   function getUser(key, server) {
	 //alert(key);
	 $('#loaderImg').show();
	 $.ajax({
		 url:'modal/userModal.php',
		 type:'POST',
		 data:{
			   key:key,
			   server:server,
			 },
		 success:function(result){
			 $('#loaderImg').hide();
			 $('#getUserModal').html(result);
			 $('#getUserPerServer').modal('show');
		 }
	 });
   }
   
   function copyToClipboard(id){
	   var copyText = document.getElementById(id);
        copyText.select();
		copyText.setSelectionRange(0, 99999); // For mobile devices
		navigator.clipboard.writeText(copyText.value);
    }
   
   function getPeKey(key) {
	 //alert(key);
	 $('#loaderImg').show();
	 $.ajax({
		 url:'modal/peKeyModal.php',
		 type:'POST',
		 data:{
			   key:key,
			 },
		 success:function(result){
			 $('#loaderImg').hide();
			 $('#getUserModal').html(result);
			 $('#getUserPerServer').modal('show');
		 }
	 });
   }
	 
	function reload(){
		 $('.modal').modal('hide');
		 location.reload();
	 }
	 
function checkEmpty(){
	$('.form-control-error').empty();
	 let action = $('#action').find(":selected").val();
	 let role = $('#role').find(":selected").val();
	 let server = $('#server').find(":selected").val();
	 let user = $('#user').find(":selected").val();
	 let ticket = $('input[name = ticket]').val();
	 let userName = $('input[name = userName]').val();
	 
	 if(ticket == '' || role == '' || server == '' || user == '' || userName == ''){
		 let ErrorTicket = ticket =='' ? "Ticket No. is required" : "";
		 let ErrorRole = role =='' ? "Role is required" : "";
		 let ErrorServer = server =='' ? "Server is required" : "";
		 let ErrorUser = user =='' ? "User is required" : "";
		 let ErrorUserName = userName =='' ? "User name is required" : "";
		    $('#ErrorTicket').html(ErrorTicket);
		    $('#ErrorRole').html(ErrorRole);
		    $('#ErrorServer').html(ErrorServer);
		    $('#ErrorUser').html(ErrorUser);
		    $('#ErrorUserName').html(ErrorUserName);
		 return;
	 }
}


       /* $('#updateStatus').change(function(){
                var inputValue = $(this).val();
                alert(inputValue);
       }); */
	   
	   function updateStatus(status, id){
		   var selectedValue = status; 
		   //var selectedValue = status.value; 
		   //var selectedText = status.options[status.selectedIndex].innerHTML; 
		   //alert(selectedValue+" "+text);
		   Swal.fire({
			title: '',
			text: 'Are you sure?',
			icon: 'info',
			input: 'textarea',
			inputPlaceholder: "Write description",
			showCancelButton: true,
			closeOnConfirm: false,
			animation: "slide-from-left",
			cancelButtonColor: '#d33',
			confirmButtonColor: '#3085d6',
			confirmButtonText: 'Yes, ' +selectedValue+ ' it!',
			showLoaderOnConfirm: true,
			}).then((result) => {
			  if(result.isConfirmed){
			     //alert(result.value);
				 $('#loaderImg').show();
				 $.ajax({
				 url:'controller/update.php',
				 type:'POST',
				 data:{
					   id: id,
					   value: selectedValue,
					   description: result.value,
					   key: 'updateRequestRole'
					 },
				 success:function(result){
					 $('#loaderImg').hide();
					 var response = JSON.parse(result);
					 //$('#getStatusModal').html(response.msg);
					 //$('#addFormModal').modal('hide');
					 //$('#successMsgModal').modal('show');
					 Swal.fire({
							text: response.text,
							icon: response.msg,
							showCancelButton: true,
							showConfirmButton: false,
							cancelButtonColor: '#d33',
							cancelButtonText: 'Close'
						}).then((result) => {
							location.reload();
					});
				 }
			   });
			 }
		  });
	   }
	   
</script>