<?php
header('Access-Control-Allow-Origin: *');

include('../../dbConnection.php');

$msg = $_REQUEST['msg'];
$uName = $_REQUEST['uName'];
$uEmail = $_REQUEST['uEmail'];
$unix_id = $_REQUEST['unix_id'];
$host_name = $_REQUEST['host_name'];
$sr_user = $_REQUEST['sr_user'];
$ip_address = $_REQUEST['ip_address'];
$server_password = $_REQUEST['server_password'];
$uID = $_REQUEST['uID'];



$sql_mail = "SELECT * FROM mails WHERE status = 1";
 $result_mail = $conn->query($sql_mail);
 $row_mail = mysqli_fetch_assoc($result_mail);
 $mailHost = $row_mail['host'];
 $mailPort = $row_mail['port'];
 $mailUser = $row_mail['user_name'];
 $mailPassword = $row_mail['password'];
 $mailSender = $row_mail['sender'];

     
	
	/************ For Pdf file creation **************/ 

	$file_name = date('His-Ymd-').$unix_id.'.pdf';
	$directory = dirname(__FILE__, 3).'/User/public/file/'.$file_name;
	
	echo $password = rand(100000, 999999);

	require('../pdf/fpdf_protection.php');
	$pdf = new FPDF_Protection();
	$pdf->SetProtection(array('print'), $password); 
	$pdf->AddPage();
	$pdf->SetFont('Arial', 'B', 18);
	$pdf->Cell(100, 12, 'Servers Details', 0);
	$pdf->Ln();
	$pdf->SetFont('Arial', 'B', 12);
	
		$pdf->Cell(32,12, 'Host Name', 1);
		$pdf->Cell(32,12, 'User', 1);
		$pdf->Cell(32,12, 'Ip Address', 1);
		$pdf->Cell(32,12, 'Password', 1);
	
	$pdf->SetFont('Arial', '', 12);
	$pdf->Ln();
	
		$pdf->Cell(32,12, $host_name, 1);
		$pdf->Cell(32,12, $sr_user, 1);
		$pdf->Cell(32,12, $ip_address, 1);
		$pdf->Cell(32,12, $server_password, 1);
	
	$pdf->Output("F",$directory);

    
	$sql_i = "INSERT INTO files (user_id, file, password) VALUES('$uID', '$file_name', '$password')";
	   $conn->query($sql_i);


    /************ For Send mail **************/ 	
	$htmlbody = 
		'<html> 
			<body> 
				<h3 style=" text-transform:capitalize;">Hello '.$uName.'</h3> 
				<p>Please find Server details below as a pdf attachment</p>
			</body> 
		 </html>';
		 
	$subject = "Requested server details";


	require('../../phpmailer/PHPMailerAutoload.php');
	
	$mail = new PHPMailer;
	$mail->isSMTP();
	$mail->SMTPDebug = 0;
	$mail->Host = $mailHost;
	$mail->Port = (int)$mailPort;
	
	if(isset($mailUser) && isset($mailPassword)){
	
		$mail->SMTPSecure = 'tls';
		$mail->SMTPAuth = true;
		$mail->Username = $mailUser;
		$mail->Password = $mailPassword;
	}
	
	$mail->setFrom($mailSender);
	$mail->addAddress($uEmail);
	$mail->addAttachment($directory);
	$mail->Subject = $subject;
	$mail->msgHTML($htmlbody);
	
	if (!$mail->send()) {
		echo "Mailer Error: ".$mail->ErrorInfo;
	}
	
?>