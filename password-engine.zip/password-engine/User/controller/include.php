<?php

include('../dbConnection.php');

include('getData.php');

include('layout/head.php');

?>