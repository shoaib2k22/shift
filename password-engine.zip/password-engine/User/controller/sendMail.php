<?php
include('../../dbConnection.php');

$uEmail = $_SESSION['uEmail'];

//$key = $_REQUEST['key'];
//$role_id = $_REQUEST['role'];
$server_id = $_REQUEST['server'];
$s_user_id = $_REQUEST['s_user'];


 $sql_mail = "SELECT * FROM mails WHERE status = 1";
 $result_mail = $conn->query($sql_mail);
 $row_mail = mysqli_fetch_assoc($result_mail);
 $mailHost = $row_mail['host'];
 $mailPort = $row_mail['port'];
 $mailUser = $row_mail['user_name'];
 $mailPassword = $row_mail['password'];
 $mailSender = $row_mail['sender'];

$msg = 0;


$sql_u = "SELECT * FROM users WHERE email= '$uEmail'";
	$result_u = $conn->query($sql_u);
	$row_u = $result_u->fetch_assoc();
	$uID = $row_u['id'];
	$uMID = $row_u['market_id'];
	$unix_id = $row_u['unix_id'];
	$uEmail = $row_u['email'];
	$uName = $row_u['f_name'].$row_u['l_name'];
 
 
 $sql_su = "SELECT servers.host_name, servers.ip_address, server_users.user, server_users.secure_key, server_users.password from servers, server_users WHERE servers.id = server_users.server_id AND server_users.id = $s_user_id AND server_users.server_id = $server_id";
	$result_su = mysqli_query($conn , $sql_su);
	$row_su = mysqli_fetch_assoc($result_su);
	$host_name = $row_su['host_name'];
	$ip_address = $row_su['ip_address'];
	$sr_user = $row_su['user'];
	$server_password = decrypt($row_su['password'], $row_su['secure_key']);
 
 


/************ For Pdf file creation **************/ 
try{
   
	$file_name = date('His-Ymd-').$unix_id.'.pdf';
	$directory = dirname(__FILE__, 3).'/User/public/file/'.$file_name;
	
	$password = rand(100000, 999999);

	require('../pdf/FPDF_Protection.php');
	$pdf = new FPDF_Protection();
	$pdf->SetProtection(array('print'), $password); 
	$pdf->AddPage();
	$pdf->SetFont('Arial', 'B', 18);
	$pdf->Cell(100, 12, 'Servers Details', 0);
	$pdf->Ln();
	$pdf->SetFont('Arial', 'B', 12);
	
		$pdf->Cell(32,12, 'Host Name', 1);
		$pdf->Cell(32,12, 'User', 1);
		$pdf->Cell(32,12, 'Ip Address', 1);
		$pdf->Cell(32,12, 'Password', 1);
	
	$pdf->SetFont('Arial', '', 12);
	$pdf->Ln();
	
		$pdf->Cell(32,12, $host_name, 1);
		$pdf->Cell(32,12, $sr_user, 1);
		$pdf->Cell(32,12, $ip_address, 1);
		$pdf->Cell(32,12, $server_password, 1);
	
	//$pdf->Output();
	//$pdf->Output("D","sho.pdf");
	//$obj_pdf->Output($clts."-".$date."-".$time.'.pdf', 'I');
	$pdf->Output("F",$directory);

	
	$sql_i = "INSERT INTO files (user_id, file, password) VALUES('$uID', '$file_name', '$password')";
	$conn->query($sql_i);
	
	
	$msg = 1;
	?>
	<!--
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
	<script> 
	  function sendMail() {
			 
			$.ajax({
				//url:'controller/sendMail.php',
				url:'http://139.47.169.69/password-engine/User/controller/sendMail_temp.php',
				type:'POST',
				data: {
					 msg: "sendPDF",
					 uName: "<?php echo $uName; ?>",
					 uEmail: "<?php echo $uEmail; ?>",
					 unix_id: "<?php echo $unix_id; ?>",
					 host_name: "<?php echo $host_name; ?>",
					 sr_user: "<?php echo $sr_user; ?>",
					 ip_address: "<?php echo $ip_address; ?>",
					 server_password: "<?php echo $server_password; ?>",
					 uID: "<?php echo $uID; ?>",
				},
				success:function(result){
					 $('#copyPassword').val(result);
				}
			});
			 
		}
		sendMail();
	</script>
	-->
	<?php
	 
		$htmlbody = 
		       '
			    <html lang="en">
				 <head>
				   <title>Password-Engine</title>
				</head>
                <body style="margin:0; padding:0; background:#f4f4f4">
				  <div class="content" id="wrapper">
					<div class="nw_layout_LAYOUT1">
					  <table align="center" border="0" cellpadding="0" cellspacing="0" class="CoverPage" id="CoverPage" style="" width="600">
						<tr>
						  <td id="header" valign="top" width="600" style="width: 100%;
							padding: 0px 0px 8px 0px;">
							<table id="nw_masthead_wrapper" class="nw_component_wrapper" cellpadding="0" cellspacing="0">
							   <tr>
								<td class="nw-componentSpacerMainCell">
									<table cellpadding="0" cellspacing="0" class="ContentBlock" id="masthead" style="margin-top:0px;margin-bottom:0px;margin-left:0px;margin-right:0px;" width="100%">
									  <tr>
										<td class="nw-componentMainCell">
										   <img alt="" src="vois.jpg" width="600" height="301" /></a>
										</td>
									  </tr>
									</table>
								</td>
							  </tr>
							</table>
						  </td> 
						</tr>
						
						<tr>
						  <td id="main" valign="top" width="600" style="width: 100%; padding-left: 0px; padding-right: 0px; background-color: #ffffff;">
							<table id="nw_maintitle_wrapper" class="nw_component_wrapper" cellpadding="0" cellspacing="0" width="100%">
							  <tr>
								<td class="nw-componentSpacerMainCell">
								   <table cellpadding="0" cellspacing="0" class="ContentBlock" id="maintitle" style="margin-top:0px;margin-bottom:0px;margin-left:0px;margin-right:0px;" width="100%">
									  <tr>
										 <td class="nw-componentMainCell">
											<table style="width: 100%;" border="0" cellpadding="0" cellspacing="0">
											   <tbody>
												 <tr>
													<td class="main_title" style="font-family: sans-serif; font-size: 16px; color: #FFFFFF; font-weight:300; font-style: normal; text-decoration: none; background-color: #000000; padding: 8px; border: 1px solid #FFFFFF;">Password Engine<br/></td>
												 </tr>
												</tbody>
											</table>
										  </td>
									  </tr>
									</table>
								</td>
							  </tr>
							</table>

							<table id="nw_maincontent_wrapper" class="nw_component_wrapper" cellpadding="0" cellspacing="0" width="100%">
								<tr>
								  <td class="nw-componentSpacerMainCell">
									 <table cellpadding="0" cellspacing="0" class="ContentBlock" id="maincontent" style="margin-top:0px;margin-bottom:0px;margin-left:0px;margin-right:0px;" width="100%">
										<tr>
										  <td class="nw-componentMainCell">
											 <table style="width: 100%;" border="0" cellpadding="0" cellspacing="0">
												<tbody>
												   <tr>
													  <td class="main_content" style="font-size: 16px; color: #000000; font-weight: normal; font-style: normal; text-decoration: none; padding: 10px;">
														<p style="margin: 1.3rem 0rem; margin-top:12px; font-size: 9pt; font-family: Calibri, sans-serif;">
														  <span style="font-family: sans-serif; color: black;">Dear Colleagues,</span>
														</p>
														
														<p style="margin: 1.3rem 0rem; font-size: 9pt; font-family: Calibri, sans-serif;">
															<span style="font-family: sans-serif; color: black;">Please find password in attached encrypted pdf file. Use passcode shared on portal to unlock it.</span>
														</p>
														
														<p style="margin: 1.3rem 0rem; font-size: 9pt; font-family: Calibri, sans-serif;">
															<span style="font-family: sans-serif; color: black;">For any queries , please feel free to reach out to <a href="#" style="color: #000000c7">pe@vodafone.com</a>
															</span>
														</p>
														
														<p style="margin-top: 50px; font-size: 11pt; font-family: Calibri, sans-serif;">
															<strong>Thank you!</strong>
														</p>
														
														<p style="margin-top: 30px; font-size: 11pt; font-family: Calibri, sans-serif;">
															<strong>Kind Regards<br/>ACC</strong>
														</p>
													  </td>
													</tr>
												</tbody>
											 </table>
										   </td>
										</tr>
									 </table>	
								   </td>
								</tr>
							</table>				 
					</body>
				</html>
							  
			 ';
			 
		$subject = "Requested server details";


		require('../../phpmailer/PHPMailerAutoload.php');
		
		$mail = new PHPMailer;
		$mail->isSMTP();
		$mail->SMTPDebug = 0;
		$mail->Host = $mailHost;
		$mail->Port = (int)$mailPort;
		
		if(isset($mailUser) && isset($mailPassword)){
		
			$mail->SMTPSecure = 'tls';
			$mail->SMTPAuth = true;
			$mail->Username = $mailUser;
			$mail->Password = $mailPassword;
		}
		
		$mail->setFrom($mailSender);
		$mail->addAddress($uEmail);
        $mail->addAttachment($directory);
		$mail->Subject = $subject;
		$mail->msgHTML($htmlbody);
		
		if (!$mail->send()) {
			echo "Mailer Error: ".$mail->ErrorInfo;
		}
}

catch(Exception $e){
    $msg = 0;
    //echo 'Message: ' .$e->getMessage();
}


function decrypt($message,$encryption_key){
	$key = $encryption_key;
	$message = base64_decode(urldecode($message));
	$nonceSize = openssl_cipher_iv_length('aes-256-ctr');
	$nonce = mb_substr($message, 0, $nonceSize, '8bit');
	$ciphertext = mb_substr($message, $nonceSize, null, '8bit');

	$plaintext= openssl_decrypt(
	  $ciphertext, 
	  'aes-256-ctr', 
	  $key,
	  OPENSSL_RAW_DATA,
	  $nonce
	);
	
  return $plaintext;
}

?>


<?php
if($msg == 1){?>
	<div id="successMsgModal" class="modal fade delete-modal" role="dialog">
		<div class="modal-dialog modal-dialog-centered">
			<div class="modal-content">
			   <div class="modal-body text-center">
					<i class="fa fa-check-square success_Msg"></i>
					<h5 class="delete_class status_header">Pdf file has sent on your mail</h5>
					<div class="pass">
					  <h4 class="status_content">Get Password:</h4>
					  <input class="fDUSOa dzARff" type="text" value="<?=$password;?>" id="copyPassword">
                      <a onclick="copy()"><i class="fa fa-clone color-gray"></i></a>
					</div>
					
					<p class="status_content">Thanks</p>
					<button type="button" class="btn btn-secondary float-right" onclick="reload()">Close</button>
				</div>
			</div>
		</div>
	</div>
<?php } ?>



<?php
if($msg == 0){?>
	<div id="successMsgModal" class="modal fade delete-modal" role="dialog">
		<div class="modal-dialog modal-dialog-centered">
			<div class="modal-content">
			   <div class="modal-body text-center">
			        <img class="failed_Msg" src="images/sent.png">
			        <!--<i class="fa fa-info-circle failed_Msg"></i>-->
					<h5 class="delete_class status_header">Please try after some time</h5>
					<p class="status_content">Thanks</p>
					<button type="button" class="btn btn-secondary float-right" class="close" data-dismiss="modal">Close</button>
				</div>
			</div>
		</div>
	</div>
<?php } ?>