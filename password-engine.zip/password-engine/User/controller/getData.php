<?php

if(isset($_SESSION['is_user_login'])){ 
	 $uEmail = $_SESSION['uEmail'];
	 
	 $userSql = "SELECT * FROM users where email = '{$uEmail}' AND is_active = 1 AND is_deleted = 0 limit 1";
	 $userResult = $conn->query($userSql);
	 
	 if(mysqli_num_rows($userResult) == 0){
		 echo "<script> location.href='../logout.php?key=1'; </script>";
	 }
	 
	 $userRow = $userResult->fetch_assoc();
	 
	 $uId = $userRow['id'];
	 $uEId = $userRow['unix_id'];
	 $uMId = $userRow['market_id'];
	 $uMobile = $userRow['mobile'];
	//  $uRole = $userRow['role'];
	 $uFName = $userRow['f_name'];
	 $uLName = $userRow['l_name'];
	 $uCA = $userRow['created_at'];
	 $uUA = $userRow['updated_at'];
	 
} else{
  echo "<script> location.href='index.php'; </script>";
}

	 	 

if(PAGE == 'dashboard'){
		$sql_assigned = "SELECT count(*) as assigned FROM grants where user_id = $uId";
			 $result_assigned = $conn->query($sql_assigned);
			 $row_assigned = mysqli_fetch_array($result_assigned);
			 $card_1_count = $row_assigned['assigned'];
			 $card_1_text = 'Assigned Role';
			 $card_1_link = 'role-assigned.php';

		 $sql_declined = "SELECT count(*) as declined FROM role_requests where user_id = $uId and is_declined = 1";
			 $result_declined = $conn->query($sql_declined);
			 $row_declined = mysqli_fetch_array($result_declined);
			 $card_2_count = $row_declined['declined'];
			 $card_2_text = 'Pending Role';
			 $card_2_link = 'role-requested.php';

		 $sql_pending = "SELECT count(*) as pending FROM role_requests where user_id = $uId and is_pending = 1";
			 $result_pending = $conn->query($sql_pending);
			 $row_pending = mysqli_fetch_array($result_pending);
			 $card_3_count = $row_pending['pending'];
			 $card_3_text = 'Declined Role';
			 $card_3_link = 'role-requested.php';
	 
	 
		 date_default_timezone_set('Asia/Calcutta');
          $Hour = date('G');
            if ( $Hour >= 5 && $Hour <= 11 ) {
				$grettings = "Good Morning";
			} else if ( $Hour >= 12 && $Hour <= 17 ) {
				$grettings = "Good Afternoon";
			} else if ( $Hour >= 15 || $Hour <= 4 ) {
				$grettings = "Good Evening";
			}

}


if(PAGE == 'role'){
	
	$sql = "SELECT roles.id as rId, roles.role as role,roles.created_at,markets.market as market, markets.id as market_id, grants.status as status FROM grants, roles, markets where grants.user_id = {$uId} AND grants.role_id = roles.id AND grants.market_id = markets.id";
		$result = $conn->query($sql);

}



if(PAGE == 'requested'){
	
	$sql = "SELECT role_requests.is_approved, role_requests.is_pending, role_requests.is_declined, role_requests.created_at, role_requests.description, markets.market as market, roles.role as role FROM role_requests, roles, markets where role_requests.user_id = {$uId} and role_requests.role_id = roles.id and role_requests.market_id = markets.id ";
		$result = $conn->query($sql);
}



if(PAGE == 'profile'){
	
     $mSql= "SELECT * FROM markets WHERE id = $uMId";
	  $mResult = $conn->query($mSql);
	  $mRow = mysqli_fetch_assoc($mResult);
	  $mMarket = $mRow['market'];
}




if(PAGE == 'getPassword'){
	
	$pSql = "SELECT * FROM files WHERE files.user_id = $uId AND status = 1 ORDER BY created_at desc";
	  $pResult = $conn->query($pSql);
	  
	$rSql = "SELECT roles.id, roles.role FROM roles,grants WHERE grants.status = 1 AND grants.role_id = roles.id AND grants.user_id = $uId AND grants.market_id = $uMId AND roles.market_id = $uMId";   
        $rResult = $conn->query($rSql);
		
	$sSql = "SELECT DISTINCT servers.host_name, servers.id FROM servers,server_users WHERE servers.id = server_users.server_id AND server_users.user_id = $uId";   
	    $sResult = $conn->query($sSql);	
	
}


if(PAGE == 'userOwnership'){
	
	  $sql = "SELECT * FROM servers, server_users WHERE server_users.user_id = $uId AND server_users.server_id = servers.id ORDER BY server_users.created_at desc";
	  $result = $conn->query($sql);
}


if(PAGE == 'userApproval'){
	
	$sql = "SELECT * FROM users, servers, server_users, grants WHERE grants.market_id = $uMId AND grants.user_id = users.id AND grants.server_id = servers.id AND grants.server_user_id = server_users.id AND server_users.user_id = $uId ORDER BY grants.created_at desc";   
      $result = $conn->query($sql);
	
}


if(PAGE == 'changepass'){
	
	 $uEmail = $_SESSION['uEmail'];
	 
	 if(isset($_REQUEST['passupdate'])){
  
		if(($_REQUEST['old_Password'] == "") || ($_REQUEST['new_Password'] == "") || ($_REQUEST['confirm_Password'] == "")){
		   $passmsg = '<div class="alert alert-warning col-sm-6 ml-5 mt-2" role="alert"> Fill All Fileds </div>';
		  }
		else {
			$sql = "SELECT * FROM users WHERE email='$uEmail'";
			$result = $conn->query($sql);
			$row = $result->fetch_assoc();
		
		if($result->num_rows == 1){
			
		if($_REQUEST['old_Password'] != $row['password']){
			$passmsg = '<div class="alert alert-warning col-sm-6 ml-5 mt-2" role="alert"> Old password not matched </div>';
		}
		if($_REQUEST['new_Password'] != $_REQUEST['confirm_Password']){
			$passmsg = '<div class="alert alert-warning col-sm-6 ml-5 mt-2" role="alert"> New & Confirm password not matched </div>';
		}
		else{
			$sql = "UPDATE users SET password = '$_REQUEST[confirm_Password]' WHERE email = '$uEmail'";
			
			if($conn->query($sql) == TRUE){
			   $passmsg = '<div class="alert alert-success col-sm-6 ml-5 mt-2" role="alert"> Updated Successfully </div>';
			 }else {
			   $passmsg = '<div class="alert alert-danger col-sm-6 ml-5 mt-2" role="alert"> Unable to Update </div>';
			  }
		}
     }
   }
 }
 
}

?>