<?php
define('TITLE', 'Get Password');
define('PAGE', 'getPassword');

include('controller/include.php');
 
?>
 
 
 <style>
  #roleBased, #serverBased{
	  display:none;
  }
  .modal-footer {
    display: flex;
    align-items: center;
    justify-content: flex-end;
    padding: 0rem;
    border-top: 0px solid #e9ecef;
  }
 </style>

 
 <div class="row">
	<div class="col-12">
		<div class="card">
			<div class="card-body">
				
				<div class="table-responsive">
				   <table class="table align-items-center table-flush data-table" id="dbtable">
					  <thead class="thead-light text-center">
					   <tr>
						  <th scope="col">#</th>
						  <th scope="col">File Name</th>
						  <th scope="col">Assigned Date</th>
						  <th scope="col">Expire At</th>
                          <th scope="col" data-orderable="false">Password</th>
						</tr>
					 </thead>
					  
					 <tbody class="text-center">
					  <?php $count = 0;
						while($pRow = $pResult->fetch_assoc()){ ?>
						<tr role="row">
						    <td scope="row"><?php echo ++$count; ?></td>
							<td><?php echo $pRow["file"]; ?></td>
							<td><?php echo $pRow["created_at"]; ?></td>
							<td><?php echo $pRow["expire_at"]; ?></td>
							<td><?php echo $pRow["password"]; ?></td>
						</tr>
					   <?php } ?>
					 </tbody> 
				  </table>
			   </div>
		   </div>
	   </div>
    </div>
 </div>

  
  
  
  


<div class="modal fade delete-modal" id="requestModal" tabindex="-1">
  <div class="modal-dialog">
	<div class="modal-content">

	  <!-- Modal Header -->
	  <div class="modal-header">
		<h4 class="modal-title">Password Request</h4>
		<button type="button" class="close" data-dismiss="modal">&times;</button>
	  </div>

	  <!-- Modal body -->
	  <div class="modal-body">
	  
	   <div class="card mx-2">
		 <div class="card-header">
		     <label for="server">Select Type</label>
			 <select class="form-control" onchange="getType(this.value)"> 
				  <option value="" disabled selected>Select Type</option> 
				  <option value="role">Role</option> 
				  <option value="server">Server</option> 
			</select>
		 </div>
		 
		 <div class="card-body" id="roleBased">
			<form id="addFormData">
			  <div class="form-group">
				 
				 <label for="role">Select Role</label>
				 <select class="form-control" name="role" id="role" onchange="getServer(this.value)"> 
					  <option value="" disabled selected>Select Role</option> 
						<?php 
						  while($rRow = mysqli_fetch_array($rResult)) { ?> 
							  <option value="<?php echo $rRow['id']; ?>"><?php echo $rRow['role']; ?></option>
					   <?php } ?>				 
				 </select>
				 
				 <div class="mt-3" id="GetServer"></div>
				 
				 <div class="mt-3" id="GetServerUser"></div>
				 
			  </div>
			</form> 
			
			<div class="modal-footer">
				 <button type="button" class="btn btn-primary" id="sendReqButton" onclick="sendFile('role')">Request</button>
				 <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
		    </div>
		 </div>
		 
		 
		 <div class="card-body" id="serverBased">
			<form id="addFormServerData">
			  <div class="form-group">
				 
				 <label for="server">Select Server</label>
				 <select class="form-control" name="server" id="server" onchange="getServerUserOnServer(this.value)"> 
					  <option value="" disabled selected>Select Server</option> 
						<?php 
						  while($sRow = mysqli_fetch_array($sResult)) { ?> 
							  <option value="<?php echo $sRow['id']; ?>"><?php echo $sRow['host_name']; ?></option>
					   <?php } ?>				 
				 </select>
				 
				 <div class="mt-3" id="GetServerUserOnServer"></div>
				 
			  </div>
			</form>

            <div class="modal-footer">
				 <button type="button" class="btn btn-primary" id="sendReqButton" onclick="sendFile('server')">Request</button>
				 <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
		    </div>
		</div>
		 
		 
			 
			 
			 
		   </div> 
				 
		   
				
		</div>
	  <!-- Modal body end-->
	</div>
  </div>
</div>



<div id="getStatusModal"></div>



<?php 
  include('layout/footer.php'); 
  $conn->close();
?>
