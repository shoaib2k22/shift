<?php
include('../../dbConnection.php');

$uEmail = $_SESSION['uEmail'];

$server_user_id = $_POST['id'];


$sql = "SELECT *, servers.id AS sId, server_users.id AS uId FROM server_users, servers WHERE server_users.id = $server_user_id AND server_users.server_id = servers.id";
  $result = $conn->query($sql);
  $row = $result->fetch_assoc();

?>

<style>
.vertical-center {
    margin-top: 30px;
}
.question{
	font-size: 18px;
    margin: 9px 4px;
    color: darkred;
}
.btn-sm {
    padding: 5px 10px;
    font-size: 12px;
    line-height: 1.5;
    border-radius: 3px;
}
.btn-danger {
    color: #fff;
    background-color: #d9534f;
    border-color: #d43f3a;
}
.form-control-error{
	color: red;
    font-size: 11px;
}
</style>

<div class="modal fade delete-modal" id="addFormModal">
    <div class="modal-dialog modal-dialog-centered modal-lg">
      <div class="modal-content">

		  <!-- Modal Header -->
		  <div class="modal-header">
			<h4 class="modal-title">Add/Remove User</h4>
			<button type="button" class="close" data-dismiss="modal">&times;</button>
		  </div>

		  <!-- Modal body -->
		  <div class="modal-body">
			<form id="addFormData">
				<div class="row formtype">
				    <div class="col-md-6">
					   <div class="form-group">
						  <label>Ticket No. <span class="text-danger">*</span></label>
						  <input class="form-control" type="text" id="ticket" name="ticket"  placeholder="e.g. VT-0527"  value="VT-0527" readonly />
						  <div id="ErrorTicket" class="form-control-error"></div>
					   </div>
					</div>
					
					<div class="col-md-6">
					  <div class="form-group">
						<label>Action <span class="text-danger">*</span></label>
						  <select class="form-control" id="action" name="action" disabled>
							  <option value="add" selected disabled>Add</option>
						  </select>
						  <div id="ErrorAction" class="form-control-error"></div>
					  </div>
					</div>
					
					<div class="col-md-12">
						<div class="form-group">
							<label>Select Server <span class="text-danger">*</span></label>
							<select class="form-control" id="server" name="server" disabled>
								<option value="<?php echo $row['sId']; ?>" selected disabled> <?php echo $row['host_name']; ?> </option>  
							</select>
							<div id="ErrorServer" class="form-control-error"></div>
						</div>
					</div>
					
					<div class="col-md-5">
						<div class="form-group">
							<label>Service / Funnctional User<span class="text-danger">*</span></label>
							<input class="form-control" type="text" id="userName" name="userName" placeholder="e.g. jPhillips" value="<?php echo $row['user']; ?>" readonly>
							<div id="ErrorUserName" class="form-control-error"></div>
							<div id="validationMessage" class="form-control-error"></div>
						</div>
					</div>
					
					<div class="col-md-5">
						<div class="form-group">
							<label>User Password<span class="text-danger">*</span></label>
							<input class="form-control" type="password" id="userPassword" name="userPassword" placeholder="********" autocomplete="new-password" required>
							<div id="ErrorPassword" class="form-control-error"></div>
						</div>
					</div>
					
					<div class="col-md-2 vertical-center">
						<div class="form-group">
							<button type="button" id="validation" class="btn btn-success" onclick="validate()">Validate</button>
						</div>
					</div>
					
					<div class="col-md-5">
						<div class="form-group">
							<label>Last Password Changed On<span class="text-danger">*</span></label>
							<div class="d-flex">
								<input class="form-control" type="date" id="changedPasswordDate" name="changedPasswordDate" required title="Please select date">
								
								<a class="cursor-pointer" data-toggle="modal" data-target="#questionModal"><i class="fa question">&#xf059;</i></a>
								
								<div class="modal fade" id="questionModal">
								  <div class="modal-dialog modal-dialog-centered" role="document">
									<div class="modal-content">
									  <div class="modal-header">
										<h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
										<button type="button" class="close" onclick="$('#questionModal').modal('hide');" aria-label="Close">
										  <span aria-hidden="true">&times;</span>
										</button>
									  </div>
									  <div class="modal-body">
										Please select date
									  </div>
									  <div class="modal-footer">
										<button type="button" class="btn btn-secondary" onclick="$('#questionModal').modal('hide');">close</button>
									  </div>
									</div>
								  </div>
								</div>
							</div>
							
							<div id="ErrorPasswordChangedDate" class="form-control-error"></div>
						</div>
					</div>
					
					<div class="col-md-5">
						<div class="form-group">
							<label>Password rotaton period<span class="text-danger">*</span></label>
							<select class="form-control" id="passwordRotationPeriod" name="passwordRotationPeriod">
							  <option value="30">30 Days</option>
							  <option value="60">60 Days</option>
							  <option value="90" selected>90 Days</option>
							</select>
							<div id="ErrorpasswordRotationPeriod" class="form-control-error"></div>
						</div>
					</div>
					
					<div class="modal-footer float-right col-md-12 p-0 pt-3">
					  <button type="button" class="btn btn-danger" id="saveServerUser" onclick="updateStatus('Approve', <?=$row['uId']?>, 'Su')" disabled>Save</button>
					  <button type="button" class="btn btn-dark" data-dismiss="modal">Close</button>
				   </div>
				   
				  </form>
				</div>
		    </div>
		</div>
	</div>
</div>