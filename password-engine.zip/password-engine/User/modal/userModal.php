<?php

$modalName = "userModal";

//include('../controller/modal.php');

include('../../dbConnection.php');

$user=$_POST['user'];
$server=$_POST['server'];

$sql = "SELECT users.email, grants.created_at, grants.status FROM users, servers, server_users, grants WHERE servers.id = grants.server_id AND server_users.id =  grants.server_user_id AND users.id = grants.user_id AND servers.host_name = '$server' AND server_users.user = '$user'";
	$result = mysqli_query($conn,$sql);

?>


	<div class="modal fade delete-modal" id="getUserPerServer">
	  <div class="modal-dialog modal-dialog-centered modal-lg">
		<div class="modal-content">

		  <!-- Modal Header -->
		  <div class="modal-header">
			<h4 class="modal-title text-capitalize"><?php echo $server; ?></h4>
			<button type="button" class="close" data-dismiss="modal">&times;</button>
		  </div>

		  <!-- Modal body -->
		  <div class="modal-body">
			 <div class="table-responsive">
				<table class="datatable table table-stripped table table-hover table-center mb-0">
					<thead>
						<tr>
							<th>#</th>
							<th>User</th>
							<th>Created On</th>
							<th>Status</th>
						</tr>
					</thead>
					<tbody>
					 <?php
					   foreach( $result as $key=>$row ){ ?>
						<tr>
							<td><?=++$key?></td>
							<td><?=$row["email"]?></td>
							
							<td><?=date('d-M-Y', strtotime($row["created_at"]))?></td>
							<td>
							   <button type="submit" class="btn btn-success btn-status">
								   <?php echo $row["status"] == 1 ? 'Active' : 'Inactive' ?>
							  </button>
							</td>
							
						 </tr>
					  <?php } ?>
					</tbody>
				</table>
			  </div>
		  </div>
		  <!-- Modal body end-->
		  
		  <!-- Modal footer -->
		  <div class="modal-footer float-right">
				<button type="button" class="btn btn-dark" data-dismiss="modal">Close</button>
		  </div>
		  <!-- Modal footer end-->
		  
		</div>
	   </div>
	 </div>
