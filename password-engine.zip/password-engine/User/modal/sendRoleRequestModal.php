<?php
include('../../dbConnection.php');

$uEmail = $_SESSION['uEmail'];

$role_id = $_REQUEST['rId'];

$msg = 0;

$sql_user = "SELECT users.id as uId, markets.id as mId FROM users,markets WHERE users.email = '$uEmail' AND users.is_active = 1 AND markets.id = users.market_id";
   $result_user = $conn->query($sql_user);
   $row_emp = $result_user->fetch_assoc();
   $market_id = $row_emp['mId'];
   $user_id= $row_emp['uId'];
   

$sql_check = "SELECT * FROM role_requests WHERE user_id = $user_id AND role_id = $role_id AND market_id = $market_id limit 1";
   $result_check = $conn->query($sql_check);
   $row_check = $result_check->fetch_assoc();

 
 if(isset($row_check)){
	 $msg = 1;
 }
 else{
	 $sql = "INSERT INTO role_requests (user_id, role_id, market_id) VALUES ($user_id,$role_id,$market_id)";
	   if($conn->query($sql) == TRUE){
		  $msg = 2;
		  //echo "Error: " . $sql . "<br>" . $conn->error;
	   }else {
		  $msg = 0;
	   }
 }
 

  
  

  
?>


<?php
if($msg == 2){?>
	<div id="successMsgModal" class="modal fade delete-modal" role="dialog">
		<div class="modal-dialog modal-dialog-centered">
			<div class="modal-content">
			   <div class="modal-body text-center">
					<i class="fa fa-check-square success_Msg"></i>
					<h5 class="delete_class status_header">Request has been sent</h5>
					<p class="status_content">Thanks</p>
					<button type="button" class="btn btn-secondary float-right" onclick="reload()">Close</button>
				</div>
			</div>
		</div>
	</div>
<?php } ?>



<?php
if($msg == 0){?>
	<div id="successMsgModal" class="modal fade delete-modal" role="dialog">
		<div class="modal-dialog modal-dialog-centered">
			<div class="modal-content">
			   <div class="modal-body text-center">
			        <img class="failed_Msg" src="images/sent.png">
					<!--<i class="fa fa-info-circle failed_Msg"></i>-->
					<h5 class="delete_class status_header">Please try after some time</h5>
					<p class="status_content">Thanks</p>
					<button type="button" class="btn btn-secondary float-right" class="close" data-dismiss="modal">Close</button>
				</div>
			</div>
		</div>
	</div>
<?php } ?>


<?php
if($msg == 1){?>
	<div id="successMsgModal" class="modal fade delete-modal" role="dialog">
		<div class="modal-dialog modal-dialog-centered">
			<div class="modal-content">
			   <div class="modal-body text-center">
			        <img class="failed_Msg" src="images/sent.png">
					<!--<i class="fa fa-info-circle failed_Msg"></i>-->
					<h5 class="delete_class status_header">You have already requested this role</h5>
					<p class="status_content">Thanks</p>
					<button type="button" class="btn btn-secondary float-right" class="close" data-dismiss="modal">Close</button>
				</div>
			</div>
		</div>
	</div>
<?php } ?>
