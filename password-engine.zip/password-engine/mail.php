<?php

include('dbConnection.php');

require('phpmailer/PHPMailerAutoload.php');

$sql_mail = "SELECT * FROM mails WHERE status = 1";
 $result_mail = $conn->query($sql_mail);
 $row_mail = mysqli_fetch_assoc($result_mail);
 $mailHost = $row_mail['host'];
 $mailPort = $row_mail['port'];
 $mailUser = $row_mail['user_name'];
 $mailPassword = $row_mail['password'];
 $mailSender = $row_mail['sender'];
 $emailReceiver = "shoaib.akhtar@vodafone.com";
	  

	$htmlbody_owner = '
			 <html> 
				<body> 
					<h3 style=" text-transform:capitalize;">Hello Shoaib</h3> 
					<p> Testing </p>
				</body> 
			 </html>';
			 
	$subject_owner = "Testing";
	
	sendMail($mailHost, $mailPort, $mailUser, $mailPassword, $mailSender, $emailReceiver, $subject_owner, $htmlbody_owner);
	




function sendMail($host, $port, $userName, $password, $sender, $email, $subject, $htmlbody){
	
	$mail = new PHPMailer;
	$mail->isSMTP();
	$mail->SMTPDebug = 0;
	$mail->Host = $host;
	$mail->Port = (int)$port;
	
	if(isset($userName) && isset($password)){
	
		$mail->SMTPSecure = 'tls';
	    $mail->SMTPAuth = true;
	    $mail->Username = $userName;
	    $mail->Password = $password;
	}
	
	$mail->setFrom($sender);
	$mail->addAddress($email);
    $mail->Subject = $subject;
	$mail->msgHTML($htmlbody);
	$mail->send();
	
	if (!$mail->send()) {
		echo "Mailer Error: ".$mail->ErrorInfo;
	}
	else{
		echo "Mail sent successfully";
	}
}

?>