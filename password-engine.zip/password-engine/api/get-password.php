<?php

header('Acess-Control-Allow-Origin: *');
header('Acess-Control-Allow-Credentials: true');
header('Acess-Control-Allow-Methods: GET,POST,OPTIONS');
header('Acess-Control-Allow-Headers: *');
header('Content-Type:application/json');

$data = json_decode(file_get_contents("php://input"),true);

$SourceServerIP = trim(isset($data['SourceServerIP']) ? $data['SourceServerIP'] : $_REQUEST['SourceServerIP']);
$SourceUserName = trim(isset($data['SourceUserName']) ? $data['SourceUserName'] : $_REQUEST['SourceUserName']);
$TargetServerName = trim(isset($data['TargetServerName']) ? $data['TargetServerName'] : $_REQUEST['TargetServerName']);
$TargetUserName = trim(isset($data['TargetUserName']) ? $data['TargetUserName'] : $_REQUEST['TargetUserName']);


//$server_name = isset($data['server_name']) ? $data['server_name'] : 'aierac01r';
//$server_name = $_SERVER['SERVER_NAME'];
//$server_address = $_SERVER['SERVER_ADDR'];



include('../dbConnection.php');


$sql_source = "SELECT * FROM servers, server_users WHERE server_users.user = '$SourceUserName' AND servers.ip_address = '$SourceServerIP' AND servers.id = server_users.server_id";
$result_source = mysqli_query($conn,$sql_source);
$row_source = mysqli_fetch_assoc($result_source);

if(!$row_source){
		echo json_encode(
		 array(
			'result'=> "validation failed",
			'message'=> "Please verify your SourceUserName and SourceServerIP",
			'status'=> 400
			));
		 exit;
	}

$sql_target = "SELECT *,server_users.password AS pass, server_users.secure_key AS sk FROM servers, server_users WHERE server_users.user = '$TargetUserName' AND servers.host_name = '$TargetServerName' AND servers.id = server_users.server_id";
$result_target = mysqli_query($conn,$sql_target);
$row_target = mysqli_fetch_assoc($result_target);

   if(!$row_target){
		echo json_encode(
		 array(
			'result'=> "validation failed",
			'message'=> "Please verify your TargetUserName and TargetServerName",
			'status'=> 400
			));
		 exit;
	}
	
	if($row_target['host_name'] == $row_source['host_name']){
		echo json_encode(
		 array(
			'result'=> "validation failed",
			'message'=> "Source server and Target server could not be same",
			'status'=> 400
			));
		 exit;
	}

$password = decrypt($row_target['pass'],$row_target['sk']);

   
   echo json_encode(
		   array(
			'password'=> $password,
			'result'=> "success",
			'message'=> "validation true",
			'status'=> 200
		));



function decrypt($message,$encryption_key){
	$key = $encryption_key;
	$message = base64_decode(urldecode($message));
	$nonceSize = openssl_cipher_iv_length('aes-256-ctr');
	$nonce = mb_substr($message, 0, $nonceSize, '8bit');
	$ciphertext = mb_substr($message, $nonceSize, null, '8bit');

	$plaintext= openssl_decrypt(
	  $ciphertext, 
	  'aes-256-ctr', 
	  $key,
	  OPENSSL_RAW_DATA,
	  $nonce
	);
	
  return $plaintext;
}

?>