<?php
header("Acess-Control-Allow-Origin: *");

echo "hello";
/*
header('Content-Type:application/json');



$data = json_decode(file_get_contents("php://input"),true);

$user_id = trim(isset($data['id']) ? $data['id'] : $_REQUEST['id']);

include('../dbConnection.php');

$sql = "select * from users where id = {$user_id}";
$result = mysqli_query($conn,$sql);
$count = mysqli_num_rows($result);

if($count>0){
	$output = mysqli_fetch_all($result, MYSQLI_ASSOC);
	echo json_encode($output);
}
else{
	echo json_encode(array('message'=>'No record found', 'status'=> false));
}
*/
?>